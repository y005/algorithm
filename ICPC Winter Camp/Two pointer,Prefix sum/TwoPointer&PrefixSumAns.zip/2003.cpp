﻿#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
#include<cstring>
#define all(v) v.begin(),v.end()

using namespace std;
using ll = long long;
ll n, m, a, b, sum, ans;
int main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	cin >> n >> m;
	vector<ll>v;
	for (int i = 0; i < n; i++) {
		cin >> a;
		v.push_back(a);
	}
	a = 0;
	while (1) {
		if (sum >= m) sum -= v[a++];
		else if (b == n) break;
		else sum += v[b++];
		if (sum == m) ans++;
	}
	cout << ans;
}