import java.util.*;

public class Main {
	
    public static void main(String args[]){
    	Scanner input=new Scanner(System.in);
    	
    	long MOD=1000000009,t;
    	int n;
    	long [] dp=new long[1000010];
    	
    	dp[1]=1;
    	dp[2]=2;
    	dp[3]=4;
    	
    	for(int i=4;i<=1000000;i++) {
    		dp[i]+=dp[i-1]+dp[i-2]+dp[i-3];
    		dp[i]%=MOD;
    	}
    	
    	t=input.nextInt();
    	
    	while(true) {
    		if(t<=0)
    			break;
    		 n=input.nextInt();
    		 System.out.println(dp[n]);
            t--;
    	}
    	
    }
}