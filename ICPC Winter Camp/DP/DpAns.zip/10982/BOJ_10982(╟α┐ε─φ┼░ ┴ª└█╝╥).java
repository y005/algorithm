package 백준문제;

import java.util.*;

public class Main {
	private static int max(int a,int b) {
		if(a>=b) return a;
		else return b;
	}
	
	private static int min(int a,int b) {
		if(a<=b) return a;
		else return b;
	}
	
    public static void main(String args[]){
    	Scanner input=new Scanner(System.in);
    	
    	int t,n,a,b,c,inf=(int) 1e9;
    	int [] dp=new int[100500];
    	
    	t=input.nextInt();
    	
    	while(t!=0) {
    		n=input.nextInt();
    		
    		for(int i=1;i<100500;i++)
    			dp[i]=inf;
    		
    		dp[0]=0;
    		
    		while(n!=0) {
    			a=input.nextInt();
    			b=input.nextInt();
    			for(int i=100000;i>=0;i--) {
    				if(i>=a) dp[i]=min(dp[i]+b,dp[i-a]);
    				else dp[i]+=b;
    			}
    			n--;
    		}
    		
    		c=inf;
    		for(int i=0;i<100001;i++)
    			c=min(c,max(dp[i],i));
    			
    		System.out.println(c);
    		t--;
    	}
    }
}