﻿#include<iostream>
#include<algorithm>

using namespace std;
int dp[10000 + 5][500 + 5][2], arr[10001], n, m;
int main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		cin >> arr[i];
	for (int i = 1; i <= n; i++)
		for (int j = 0; j <= m; j++) {
			if (j != 1) {
				if (j) {//j가 0이라면 dp[i-1][j-1]에 접근하지 못한다.
					dp[i][j][1] = dp[i - 1][j - 1][1] + arr[i];
					dp[i][j][0] = max(dp[i - 1][j + 1][1], dp[i - 1][j + 1][0]);
				}
				else {
					//j가 0일이면서 달리는 경우는 없다.
					dp[i][j][0] = max({ dp[i - 1][j + 1][0], dp[i - 1][j + 1][1],dp[i - 1][j][0] });
					//j가 0일때 쉬면, 다시 j가 0인 것을 생각해주자. 지침지수가 0보다 내려갈 수가 없으니까.
				}
			}
			else {
				dp[i][j][1] = max(dp[i - 1][j - 1][1], dp[i - 1][j - 1][0]) + arr[i];
				dp[i][j][0] = max(dp[i - 1][j + 1][1], dp[i - 1][j + 1][0]);
			}
		}
	cout << dp[n][0][0];
}