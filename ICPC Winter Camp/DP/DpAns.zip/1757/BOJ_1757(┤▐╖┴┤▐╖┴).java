package 백준문제;

import java.util.*;

public class Main {
	private static int max(int a,int b) {
		if(a>=b) return a;
		else return b;
	}
	
	private static int max(int a,int b, int c) {
		if(a>=b&&a>=c) return a;
		else if(b>=a&&b>=c) return b;
		else return c;
	}
    public static void main(String args[]){
    	Scanner input=new Scanner(System.in);
    	
    	int [][][] dp=new int[10005][505][2];
    	int [] arr=new int[10001];
    	int n,m;
    	
    	n=input.nextInt();
    	m=input.nextInt();
    	
    	for(int i=1;i<=n;i++)
    		arr[i]=input.nextInt();
    	
    	for(int i=1;i<=n;i++) {
    		for(int j=0;j<=m;j++) {
    			if(j!=1) {
    				if(j!=0) {
    					dp[i][j][1]=dp[i-1][j-1][1]+arr[i];
    					dp[i][j][0]=max(dp[i-1][j+1][1],dp[i-1][j+1][0]);
    				}
    				else {
    					dp[i][j][0]=max(dp[i-1][j+1][0],dp[i-1][j+1][1],dp[i-1][j][0]);
    				}
    			}
    			else {
    				dp[i][j][1]=max(dp[i-1][j-1][1],dp[i-1][j-1][0])+arr[i];
    				dp[i][j][0]=max(dp[i-1][j+1][1],dp[i-1][j+1][0]);
    			}
    		}
    	}
    	System.out.println(dp[n][0][0]);
    			
    }
}