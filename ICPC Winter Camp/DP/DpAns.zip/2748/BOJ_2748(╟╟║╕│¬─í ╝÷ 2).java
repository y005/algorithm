import java.util.*;

public class Main {
	private static long [] fib=new long[100];
	
	private static long fibo(int n) {
		if(fib[n]!=-1) return fib[n];
		if(n<2) return fib[n]=n;
		return fib[n]=fibo(n-1)+fibo(n-2);
	}
	
    public static void main(String args[]){
    	Scanner input=new Scanner(System.in);
    	
    	int n;
    	for(int i=0;i<100;i++)
    		fib[i]=-1;
    	n=input.nextInt();
    	System.out.println(fibo(n));
    	
    }
}