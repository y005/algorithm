﻿#include<iostream>
#include<cstring>

using namespace std;
using ll = long long;
ll fib[100], n;
ll fibo(int n) {
	if (fib[n] != -1)return fib[n];
	if (n < 2)return fib[n] = n;
	return fib[n] = fibo(n - 1) + fibo(n - 2);
}
int main() {
	for (int i = 0; i < 100; i++)fib[i] = -1;
	cin >> n;
	cout << fibo(n);
}
