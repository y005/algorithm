#include<iostream>
using namespace std;
#define MAX 10

int N, M;
int answer[MAX]; // ����� ���ڵ��� �����ؼ� ��¿�

void solve(int level, int num) {
	if (level == M) {
		for (int i = 0; i < M; i++)cout << answer[i] << " ";
		cout << '\n';
		return;
	}
	for (int i = num; i <= N; i++) {
		answer[level] = i;
		solve(level + 1, i+1);
	}
}

int main() {
	cin >> N >> M;
	solve(0, 1);
}