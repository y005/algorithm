package Prob_2847;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		int v[] = new int [n];
		
		for(int i = 0; i < n ; i++) {
			v[i] = in.nextInt();
		}
		int ans = 0;
		for(int i = n - 2; i >= 0; i--) {
			if(v[i+1] <= v[i])
				ans += v[i] - (v[i + 1] - 1);
			v[i] = v[i] < (v[i + 1] - 1) ? v[i] : (v[i + 1] - 1);
		}
		System.out.println(ans);
		
		in.close();
	}

}
