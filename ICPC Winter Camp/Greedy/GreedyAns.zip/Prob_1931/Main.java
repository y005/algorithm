package Prob_1931;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int v [][] = new int[n][2];
		
		for(int i = 0; i < n; i++) {
			v[i][0] = in.nextInt();
			v[i][1] = in.nextInt();
		}
		
		Arrays.sort(v, new Comparator<int[]>() {
			public int compare(int[] e1, int[] e2) {
				if(e1[1] == e2[1]) {
					return e1[0] - e2[0];
				}
				return e1[1] - e2[1];
			}
		});
		
		int a = 0, b = 0;
		
		for(int i = 0; i < n; i++) {
			if(v[i][1] < a)continue;
			a = v[i][0];
			b++;
		}
		
		System.out.println(b);
		
		in.close();
	}

}
