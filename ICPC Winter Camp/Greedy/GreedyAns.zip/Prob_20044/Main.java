package Prob_20044;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		n *= 2;
		int v [] = new int [n];
		
		for(int i = 0; i < n; i++) {
			v[i] = in.nextInt();
		}
		Arrays.sort(v);
		int a = 1234567891;
		for(int i = 0; i < n; i++) {
			a = a < (v[i] + v[n - 1 - i]) ? a : (v[i] + v[n - 1 - i]);
		}
		
		System.out.println(a);
		
		in.close();
	}

}
