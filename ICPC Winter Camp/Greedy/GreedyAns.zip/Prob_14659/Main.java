package Prob_14659;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		int v[] = new int[n];
		
		for(int i = 0; i < n; i++) {
			v[i] = in.nextInt();
		}
		int max = 0, ans = 0, a = 0;
		for(int i = 0 ;i < n; i++) {
			if(max < v[i]) {
				max = v[i];
				ans = ans > a ? ans : a;
				a = -1;
			}
			a++;
		}
		ans = ans > a ? ans : a;
		System.out.println(ans);
		
		in.close();
	}

}
