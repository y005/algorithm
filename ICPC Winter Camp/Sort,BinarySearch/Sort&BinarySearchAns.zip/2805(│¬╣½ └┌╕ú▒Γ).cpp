#include<iostream>
#include<algorithm>
using namespace std;

int num[1000005];

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	int n, m;
	cin >> n >> m;
	int high = 0, low = 0, mid;
	for (int i = 0; i < n; i++) {
		cin >> num[i];
		high = max(high, num[i]);
	}
	long long sum;
	int ans = -1;
	while (high >= low) {
		mid = (high + low) / 2;
		sum = 0;
		for (int i = 0; i < n; i++) {
			if (num[i] - mid > 0)sum += num[i] - mid;
		}
		if (sum < m) high = mid - 1;
		else {
			ans = max(ans, mid);
			low = mid + 1;
		}
	}
	cout << ans;
}