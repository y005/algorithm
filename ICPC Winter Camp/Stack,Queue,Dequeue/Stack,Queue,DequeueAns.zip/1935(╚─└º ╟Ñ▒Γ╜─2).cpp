#include<iostream>
#include<stack>
#include<string>
using namespace std;

string s;
double num[26];

int main() {
	cout << fixed; 
	cout.precision(2); // �Ҽ��� ���ڸ����� ����ϱ� ���ؼ� 
	int n;
	cin >> n;
	cin >> s;
	for (int i = 0; i < n; i++) cin >> num[i];
	stack<double> st;
	for (int i = 0; i < s.length(); i++) {
		if (s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-') {
			double a = st.top();
			st.pop();
			double b = st.top();
			st.pop();
			if (s[i] == '*') {
				st.push((1.0)*b*a);
			}
			else if (s[i] == '/') {
				st.push((1.0)*b / a);
			}
			else if (s[i] == '+') {
				st.push(b + a);
			}
			else if (s[i] == '-') {
				st.push(b - a);
			}
		}
		else {
			st.push(num[s[i] - 'A']);
		}
	}
	cout << st.top();
}