#include<iostream>
#include<string>
#include<deque>
using namespace std;

string s;
deque<char> cal;
deque<long long> num;

int main() {
	cin >> s;
	int n = s.length();
	if (s[0] == '-') {  //ó�� ���� ������ ������ ���
		bool check = true; // ������ �ѹ��� ó���ϱ� ���ؼ� 
		for (int i = 1; i < n;) {
			if (s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-') {
				cal.push_back(s[i]);
				i++;
			}
			else {
				long long a = 0;
				while (!(s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-') && i < n) {
					a = a * 10 + s[i] - '0'; // string�� ���� �ϳ��� ���� ������ �츮�� ���ϴ� ������ ����ϴ� �� 
					i++;
				}
				if (check) { // ���� ó�� ���� ��������
					check = false;
					num.push_back(-a); // ���� ó�� �� check -> false
				}
				else num.push_back(a);

			}
		}
	}
	else {
		for (int i = 0; i < n;) {
			if (s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-') {
				cal.push_back(s[i]);
				i++;
			}
			else {
				long long a = 0;
				while (!(s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-') && i < n) {
					a = a * 10 + s[i] - '0';
					i++;
				}
				num.push_back(a);
			}
		}
	}

	while (num.size() > 1) {
		int last = num.size() - 1;
		char a = cal.front(); // ������1
		char b = cal.back(); // ������2
		long long q = num[0]; // ��1 
		long long w = num[1]; // ��2
		long long e = num[last - 1]; // ��1
		long long r = num[last]; // ��2
		long long num1, num2;
		if (a == '*' || a == '/') {
			if (b == '*' || b == '/') {
				if (a == '*')num1 = q * w;
				else num1 = q / w;
				if (b == '*')num2 = e * r;
				else num2 = e / r;
				if (num1 >= num2) {
					num.pop_front();
					num.pop_front();
					num.push_front(num1);
					cal.pop_front();
				}
				else {
					num.pop_back();
					num.pop_back();
					num.push_back(num2);
					cal.pop_back();
				}
			}
			else {
				if (a == '*')num1 = q * w;
				else num1 = q / w;
				num.pop_front();
				num.pop_front();
				num.push_front(num1);
				cal.pop_front();
			}
		}
		else {
			if (b == '*' || b == '/') {
				if (b == '*')num2 = e * r;
				else num2 = e / r;
				num.pop_back();
				num.pop_back();
				num.push_back(num2);
				cal.pop_back();
			}
			else {
				if (a == '+')num1 = q + w;
				else num1 = q - w;
				if (b == '+')num2 = e + r;
				else num2 = e - r;
				if (num1 >= num2) {
					num.pop_front();
					num.pop_front();
					num.push_front(num1);
					cal.pop_front();
				}
				else {
					num.pop_back();
					num.pop_back();
					num.push_back(num2);
					cal.pop_back();
				}
			}
		}
	}
	cout << num.front();
}